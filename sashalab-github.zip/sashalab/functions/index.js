const {onDocumentUpdated}=require('firebase-functions/v2/firestore');
const admin=require('firebase-admin');
admin.initializeApp();
async function send(tokens,title,body){
  tokens=[...new Set(tokens||[])];
  if(!tokens.length)return;
  await admin.messaging().sendEachForMulticast({tokens,data:{title,body}});
}
exports.notify=onDocumentUpdated('students/{id}',async ev=>{
  const a=ev.data.before.data(),b=ev.data.after.data();
  const ma=(a.msgs||[]).length,mb=(b.msgs||[]).length;
  const meta=(await admin.firestore().doc('meta/main').get()).data()||{};
  if(mb>ma){
    const last=b.msgs[mb-1];
    if(last.from==='t')await send(b.fcm,'SashaLab – nová zpráva',String(last.text).slice(0,120));
    else await send(meta.tt,'Zpráva od '+b.first+' '+b.last,String(last.text).slice(0,120));
  }
  if((b.tasks||[]).length>(a.tasks||[]).length)await send(b.fcm,'Nový domácí úkol',String(b.tasks[0].title));
  if((b.invoices||[]).length>(a.invoices||[]).length)await send(b.fcm,'Nová žádost o platbu','Podívej se do sekce Platby.');
});
