importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');
firebase.initializeApp({
  apiKey: "AIzaSyCa7tZycA4q9MrZJ6vsSjSB33bJ-AoOeUk",
  authDomain: "sashalab-claude.firebaseapp.com",
  projectId: "sashalab-claude",
  storageBucket: "sashalab-claude.firebasestorage.app",
  messagingSenderId: "610349992251",
  appId: "1:610349992251:web:bf28c68e07a567ac5d0f1e"
});
const m=firebase.messaging();
m.onBackgroundMessage(p=>{const n=p.data||{};self.registration.showNotification(n.title||'SashaLab',{body:n.body||'',icon:'icon-192.png'})});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.openWindow('./'))});
