# SashaLab Guitar School – školní systém

Jeden soubor `index.html` (bez buildu). Funguje ve dvou režimech:
- **Lokální** (bez Firebase): data jsou v prohlížeči, přepínač Učitel / Žák.
- **Cloud** (Firebase): živá synchronizace, přihlášení učitele e-mailem a žáků kódem + PIN.

## 1. Firebase (jednorázově)
1. https://console.firebase.google.com → vytvoř projekt.
2. **Authentication** → Sign-in method → zapni **E-mail/heslo**.
3. Authentication → Users → **přidej uživatele (učitele)** s tvým e-mailem a heslem.
4. **Firestore Database** → vytvoř databázi (production mode).
5. Firestore → Rules → vlož obsah `firestore.rules`, v něm změň `UCITEL@example.cz` na e-mail učitele a dej Publish.
6. Project settings → Your apps → Web app (`</>`) → zkopíruj `firebaseConfig`.
7. Vlož ho do `index.html` do konstanty `FB_CONFIG` (hned na začátku skriptu), aby fungoval i žákům na telefonech. `firebaseConfig` není tajný.
8. Authentication → Settings → Authorized domains → přidej `TVOJEJMENO.github.io`.

## 2. GitHub Pages
1. Nový repozitář, nahraj `index.html`, `firestore.rules`, `README.md`.
2. Settings → Pages → Deploy from branch → `main` / root.
3. Adresa: `https://TVOJEJMENO.github.io/NAZEV-REPOZITARE/`

## 3. Lokálně
Firebase nefunguje z `file://`. Spusť ve složce `python3 -m http.server 8000` a otevři `http://localhost:8000`.
Bez konfigurace Firebase se aplikace dá otevřít i dvojklikem (lokální režim).

## 4. Žáci
Učitel → Žáci → **Vytvořit přístup**: vznikne kód a 6místný PIN. Tlačítko **Pozvánka** otevře e-mail se vším potřebným.
Žák se přihlásí na záložce Žák, vidí jen svůj profil a může odškrtávat úkoly.

## 5. Rodiče
Žáci → u nezletilého **Přístup pro rodiče**: vznikne kód a PIN, který platí pro všechny děti se stejným e-mailem zástupce. Rodič se přihlásí na záložce **Rodič** a vidí souhrn rodiny, platby s QR kódem a může přepínat mezi dětmi.

## 6. Přílohy, výkazy, vzhled
- Přílohy: do úkolu vlož odkazy (Google Drive, GitHub), bez limitu Firestore. Sdílení souborů na Drive nastav na „kdokoli s odkazem“.
- Výkazy: záložka **Výkazy** (příjmy po měsících, podle žáků, CSV pro účetní a PDF).
- Nastavení → barva školy a logo (použije se v aplikaci i na PDF).

## 7. Zprávy, repertoár, online lekce, předplatné
- **Zprávy:** vlákno lektor ↔ žák/rodič, nepřečtené se ukazují v menu a na přehledu, hromadné oznámení všem žákům.
- **Repertoár:** knihovna skladeb s odkazem na tabulaturu/PDF/video, zadání skladby žákovi, stav Nacvičuje se / Zvládnuto.
- **Online lekce:** u lekce vyber Online a vlož odkaz (Meet, Zoom), žák vidí tlačítko Připojit se.
- **Omluvy:** žák klikne Omluvit (nejpozději X hodin předem, nastavuje se v Nastavení), lektor schválí nebo zamítne na přehledu.
- **Opakované platby:** Platby → Opakované platby. Žádosti se vytvoří samy při otevření aplikace lektorem.
- **Druhý lektor:** přidej jeho e-mail do `firestore.rules` a vytvoř mu účet v Authentication. Uvidí všechny žáky.

## 8. Upozornění (push), kredity, instalace do telefonu
- **Kredit na náhradu:** schválená omluva (podaná nejpozději X hodin předem) přidá žákovi 1 kredit. Při plánování lekce zaškrtni „Náhrada“ a kredit se odečte. Kredity lze ručně upravit v Docházce.
- **Upozornění při otevřené aplikaci** fungují hned: tlačítko „Zapnout upozornění“ (nahoře) povolí oznámení prohlížeče, zobrazí se při novém úkolu nebo zprávě, když je aplikace na pozadí.
- **Push do telefonu i při zavřené aplikaci** potřebuje server (Cloud Function) a tarif Blaze (platba podle spotřeby, pro tuto školu v řádu nuly):
  1. Firebase konzole → Project settings → Cloud Messaging → Web Push certificates → **Generate key pair**. Veřejný klíč vlož do `FB_VAPID` v `index.html`.
  2. V terminálu: `npm i -g firebase-tools`, `firebase login`, ve složce projektu `firebase init functions` (použij existující složku `functions`, nepřepisuj `index.js`) a `firebase deploy --only functions`.
  3. `firebase-messaging-sw.js`, `manifest.json` a ikony musí ležet vedle `index.html`.
- **iPhone:** push funguje jen po přidání na plochu (Sdílet → Přidat na plochu) a od iOS 16.4.

## Omezení
- Firestore: max 1 MB na žáka, proto přílohy do 300 kB a hlas do 60 s. Větší soubory řeš odkazem (např. Google Drive).
- Když lektor a žák zapíšou do stejného profilu ve stejném okamžiku, může se jedna ze změn přepsat (výjimečně).
- Předplatné se generuje jen v klientovi lektora, ne na serveru. Při dvou lektorech otevřených současně může vzniknout duplicitní žádost, proto ji případně smaž.
- Knihovna skladeb a předplatné jsou v dokumentu `meta/main`, který čtou i přihlášení žáci (bez jmen, jen interní ID).
- PIN má 6 číslic (minimum Firebase). Reset PINu = **Nový přístup** (starý přístup přestane být propojen).
- Přílohy se na Drive ani GitHub samy nenahrávají (chtělo by to OAuth, resp. token v prohlížeči, což není bezpečné). Vlož odkaz.
- Google Kalendář: odkaz „Přidat do Google Kalendáře“ u lekce a export `.ics` (import do Google/Apple/Outlook). Automatická obousměrná synchronizace přes Google API vyžaduje OAuth klíč, zatím není.
- QR platba (formát SPAYD) se vytvoří, jen když je v Nastavení vyplněný IBAN.
- Upomínky se připravují jako e-mail (tlačítko otevře tvůj e-mailový program) a zapisují se do aktualizací žáka. Odesílání na pozadí aplikace nedělá.
- Registraci nových účtů Firebase neomezuje; data žáků chrání pravidla v `firestore.rules`.
